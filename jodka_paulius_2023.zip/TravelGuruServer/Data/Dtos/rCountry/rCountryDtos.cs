﻿using TravelGuruServer.Entities;

namespace TravelGuruServer.Data.Dtos.rCountry;

// NEREIKIA
