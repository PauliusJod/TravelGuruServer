﻿namespace TravelGuruServer.Auth.Model
{
    public interface IUserOwnedResource
    {
        public string UserId { get; }
    }
}
