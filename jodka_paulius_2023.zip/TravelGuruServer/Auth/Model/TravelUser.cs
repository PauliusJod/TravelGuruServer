﻿using Microsoft.AspNetCore.Identity;

namespace TravelGuruServer.Auth.Model
{
    public class TravelUser : IdentityUser
    {
    }
}
