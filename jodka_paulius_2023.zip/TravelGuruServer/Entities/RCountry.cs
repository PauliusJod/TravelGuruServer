﻿using System.ComponentModel.DataAnnotations;

namespace TravelGuruServer.Entities
{
    public class RCountry // Nereikia
    {

    }
}
