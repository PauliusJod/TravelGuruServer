﻿using Microsoft.AspNetCore.Mvc;
using TravelGuruServer.Data.Dtos.Section;
using TravelGuruServer.Data.Dtos.TRoute;
using TravelGuruServer.Entities;
using TravelGuruServer.Repositories;

namespace TravelGuruServer.Controllers
{

 
}
